import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Map.Entry;
import java.util.Scanner;

import edu.du.dudraw.DUDraw;

public class DataAnalysis {
	private Scanner numScanner;
	private Scanner nameScanner;
	private Scanner keyboard;
	private String fileName;
	private double totalBorn;
	private int yearCount;
	private double maxFreq;
	private int freqYear;
	private int firstYear;
	private static final int START_YEAR = 1880;
	private static final int FINAL_YEAR = 2021;
	private static final int NUMYEARS = (FINAL_YEAR - START_YEAR) + 1;
	private static HashMap<String, Double>[] dataMap = new HashMap[NUMYEARS];

	public DataAnalysis() {
		keyboard = new Scanner(System.in);
		readFile();
		userEntry();
	}

	private void readFile() {
		yearCount = 0;
		// loop through each year starting with 1880 up to 2021
		for (int i = START_YEAR; i <= FINAL_YEAR; i++) {
			// create a new string based on the current year
			fileName = "yob" + i + ".txt";
			totalBorn = 0;
			int nameTotal = 0;
			// instantiate a new HashMap and add it to the array
			HashMap<String, Double> nameMap = new HashMap<String, Double>();
			dataMap[yearCount] = nameMap;

			// create a scanner to read the total number of babies born in a year
			// and get the sum
			try {
				numScanner = new Scanner(new File(fileName));
				while (numScanner.hasNextLine()) {
					String line = numScanner.nextLine();
					String[] tokens = line.split(",");
					totalBorn += Integer.parseInt(tokens[2]);
				}
			} catch (FileNotFoundException e) {
				e.printStackTrace();
			}

			// Scan through the file and add each name as a key with an associated value
			try {
				nameScanner = new Scanner(new File(fileName));
				while (nameScanner.hasNextLine()) {
					String line = nameScanner.nextLine();
					String[] tokens = line.split(",");
					// if the name is already in the map, store the current value associated
					if (dataMap[yearCount].get(tokens[0]) != null) {
						nameTotal = (int) ((dataMap[yearCount].get(tokens[0])) * totalBorn);
					}

					// calculate the frequency of the name based on the babies born
					// and add it to the map
					double value = (nameTotal + Integer.parseInt(tokens[2])) / totalBorn;

					nameMap.put(tokens[0], value);
				}
			} catch (FileNotFoundException e) {
				e.printStackTrace();
			}

			yearCount++;
		}

	}

	public void userEntry() {

		System.out.println("Please enter a name or year: ");
		do {
			// store input from the user
			String userInput = keyboard.next();
			if (userInput.charAt(0) == '1' || userInput.charAt(0) == '2') {
				numericalInput(userInput);
			} else {
				// loop through each HashMap, finding the values associated with the given name
				for (int i = 0; i < dataMap.length; i++) {
					int currentYear = 1880 + i;
					double yearlyValue = 0;
					if (dataMap[i].get(userInput) != null) {
						yearlyValue = dataMap[i].get(userInput);
						if (dataMap[i].get(userInput) > maxFreq) {
							maxFreq = dataMap[i].get(userInput);
							freqYear = 1880 + i;
						}
					}

				}
				// loop through the HashMap and find the first year that a name occurs
				for (int i = 0; i < dataMap.length; i++) {
					if (dataMap[i].get(userInput) != null) {
						firstYear = 1880 + i;
						break;
					}
				}
				drawGraph(userInput);
			}
		} while (!keyboard.next().equals("exit"));
	}

	public void numericalInput(String y) {
		System.out.println("How many names would you like from " + y + "?");
		String userInput = keyboard.next();
		double maxVal = 0.0;
		int numNames = Integer.parseInt(userInput);
		// create a list of values and names that have coinciding positions
		List<Double> numList = (List<Double>) dataMap[FINAL_YEAR - Integer.parseInt(y)].values();
		List<String> nameList = (List<String>) dataMap[FINAL_YEAR - Integer.parseInt(y)].keySet();
		// loop through and find n names
		for (int i = 0; i < numNames; i++) {
			maxVal = 0;
			// loop through the list and values and find the max
			for (int j = 0; j < numList.size(); j++) {
				if (numList.get(j) > maxVal) {
					maxVal = numList.get(j);
				}
			}
			// find the coinciding name for the maximum and return and remove both
			for (int k = 0; k < numList.size(); k++) {
				if (numList.get(k).equals(maxVal)) {
					System.out.println(nameList.get(k) + ": " + numList.get(k));
					numList.remove(k);
					nameList.remove(k);
					break;
				}
			}
			System.out.print("");
		}

	}

	public void drawGraph(String n) {
		// set the canvas size and the scale
		DUDraw.setCanvasSize(500, 500);
		DUDraw.setXscale(0, 142);
		DUDraw.setYscale(0, maxFreq * 1.1);
		// loop through the length of the HashMap and draw the proper bar of the graph
		for (int i = 0; i < dataMap.length; i++) {
			if (dataMap[i].get(n) != null) {
				DUDraw.filledQuadrilateral(i + 1, 0, i, 0, i, dataMap[i].get(n), i + 1, dataMap[i].get(n));
			} else {
				DUDraw.filledQuadrilateral(i + 1, 0, i, 0, i, 0.00001, i + 1, 0.00001);
			}
		}
		// display information regarding the frequency and appear of the given name
		DUDraw.text(142 / 2, maxFreq * 1.05, n + "," + " first year: " + firstYear);
		DUDraw.text(142 / 2, maxFreq * 1.01, "Maximum Frequency: " + maxFreq * 100 + "% in " + freqYear);
	}

}
