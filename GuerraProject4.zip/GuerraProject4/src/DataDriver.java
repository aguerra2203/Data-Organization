import java.util.Scanner;

public class DataDriver {

	public static void main(String[] args) {
		DataAnalysis data = new DataAnalysis();

	}

}
